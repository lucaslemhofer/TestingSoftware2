# SIGEX — pruebas automatizadas para VS Code

Proyecto Python + Selenium + pytest para abrir en VS Code y ejecutar desde tu equipo. La matriz completa CP01–CP32, con descripción, CU/RF, flujo y prioridad, está en `docs/MATRIZ.md` y `data/casos.json`.

## Estado

Hay código preparado para CP01–CP05, CP07, CP09, CP11, CP26, CP28–CP30, además de tres smoke del formulario de acceso. Los otros 20 CP se muestran como `SKIPPED` en pytest y explican por qué en la matriz. Un caso «implementado» todavía no significa que se haya probado ni aprobado al ejecutarlo en tu equipo. Las funciones no confirmadas no se reportan como fallidas ni se simulan como aprobadas.

La recuperación de la conversación anterior no incluía la tabla completa; ahora se incorporó la tabla que compartiste. Los selectores del ingreso, del alta/búsqueda/detalle de expedientes, el pase y la creación de nota se basan en la interfaz observada. En los requerimientos ya marcados «Implementado» pero cuyas pantallas o reglas no se inspeccionaron, el script deja el caso omitido con esa limitación.

## Preparar en Windows

1. Instala Python 3.12 o posterior y Google Chrome.
2. Abre esta carpeta en VS Code y su terminal PowerShell.
3. Ejecuta:

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
```

Para la cuenta de demostración que SIGEX publica en su pantalla de acceso, abre `.env` y cambia `SIGEX_USE_DEMO=false` a `SIGEX_USE_DEMO=true`. El script lee la cuenta y clave de esa pantalla; no están guardadas en los archivos. Para otra cuenta, deja la opción en `false` y pon los datos autorizados solo en `.env`, que Git ignora.

## Ejecutar

```powershell
.\.venv\Scripts\python.exe -m pytest
.\.venv\Scripts\python.exe -m pytest -m smoke
.\.venv\Scripts\python.exe -m pytest tests/test_expedientes.py
.\.venv\Scripts\python.exe -m pytest -k CP01
```

La suite crea expedientes nuevos con identificadores `AUTO-...`. CP07 mueve el expediente sintético a «En trámite». CP09 agrega una nota de prueba. No dirijas los casos a expedientes reales de otras personas. CP03 valida el rechazo del formato inválido; si SIGEX lo acepta, pytest lo mostrará como `FAILED` para que puedas revisar ese resultado.

## Reportes y secretos

`reports/report.html` y `reports/results.xml` contienen el resumen; las capturas de fallos quedan en `screenshots/`. La configuración intenta ocultar campos y cuentas visibles antes de capturar. Revisa las capturas antes de compartirlas. `.gitignore` excluye `.env`, reportes, capturas, caches y el entorno virtual.

`PASSED` indica que la comprobación pasó en esa ejecución; `FAILED`/`ERROR` indica un fallo; `SKIPPED` significa que el caso está pendiente según `docs/MATRIZ.md`. No se transforma un fallo de infraestructura en un `xfail`.

## GitHub

El proyecto no está publicado en GitHub. Antes de subirlo hace falta escoger el nombre y la visibilidad del repositorio. Comprueba `git status` y no agregues `.env`, capturas ni reportes.
