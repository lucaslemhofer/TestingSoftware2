import pytest

def test_CP09_elaborar_documento(expedientes, numero):
    from pages.documentos_page import DocumentosPage
    expedientes.create(numero)
    expedientes.detail(numero)
    DocumentosPage(expedientes.driver).create_note('Nota ' + numero, 'Contenido sintetico ' + numero)





@pytest.mark.pendiente
@pytest.mark.skip(reason='Falta inspeccionar los controles para seleccionar y editar un documento persistido.')
def test_CP10_editar_documento_procesal():
    """Editar documento procesal: Verificar que un documento existente pueda modificarse y que los cambios sean almacenados correctamente."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='RF08 figura como Implementado; falta inspeccionar el modulo y selectores para el rol Secretario Relator/Juez.')
def test_CP16_crear_borrador_correctamente():
    """Crear borrador correctamente: Verificar que un Secretario Relator/Juez pueda crear un borrador asociado a un expediente disponible o asignado."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='RF08 figura como Implementado; falta localizar y editar un borrador existente con el rol habilitado.')
def test_CP17_continuar_edici_n_de_un_borrador():
    """Continuar edición de un borrador: Abrir un borrador existente, modificarlo y verificar que los cambios puedan guardarse correctamente."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='RF08 figura como Implementado; falta comprobar la regla de asignacion y el mensaje de rechazo.')
def test_CP18_crear_borrador_sin_expediente_v_lido_asignado():
    """Crear borrador sin expediente válido/asignado: Intentar crear un borrador cuando el expediente no se encuentra disponible o asignado al usuario correspondiente."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='RF07 figura como Validado; no se confirmo una pantalla funcional de control de agravios.')
def test_CP19_controlar_agravios():
    """Controlar agravios: Verificar que el Secretario Relator pueda realizar el control de agravios correspondiente al expediente."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='RF10 figura como Implementado; falta inspeccionar las acciones de versionado y sus controles.')
def test_CP20_generar_nueva_versi_n_de_documento():
    """Generar nueva versión de documento: Modificar un documento existente y verificar que el sistema registre una nueva versión sin perder la anterior."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='RF10 figura como Implementado; falta inspeccionar la vista de historial de versiones.')
def test_CP21_consultar_historial_de_versiones():
    """Consultar historial de versiones: Verificar que puedan identificarse las modificaciones y versiones registradas de un documento."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='RF07 figura como Validado; falta comprobar la gestion de providencias en el rol Secretario de Tramite.')
def test_CP22_administrar_providencia():
    """Administrar providencia: Verificar que el Secretario de Trámite pueda crear o gestionar una providencia asociada al expediente."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='RF09 figura como Propuesto en el informe citado; el envio al firmador no esta confirmado.')
def test_CP23_enviar_documento_al_firmador():
    """Enviar documento al firmador: Verificar que un documento preparado para firma pueda enviarse correctamente al proceso de firma."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')
