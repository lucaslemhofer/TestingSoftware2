import pytest



def test_CP29_consultar_estado_actual(expedientes, numero):
    expedientes.create(numero)
    row=expedientes.exact_rows(numero)[0]
    assert 'Registrado' in row.text
    expedientes.detail(numero)
    assert 'Registrado' in expedientes.visible(('tag name','body')).text


def test_CP30_consultar_historial_de_movimientos(expedientes, numero):
    expedientes.create(numero)
    expedientes.detail(numero)
    comment='Historial CP30 ' + numero
    expedientes.transfer(comment)
    body=expedientes.visible(('tag name','body')).text
    assert comment in body
    assert 'En trámite' in body
