import pytest

pytestmark = pytest.mark.smoke


def test_acceso_formulario(login):
    assert login.visible(login.EMAIL).get_attribute("type") == "email"
    assert login.visible(login.PASSWORD).get_attribute("type") == "password"
    assert login.visible(login.SUBMIT).is_enabled()


def test_acceso_requiere_email(login):
    login.fill("", "")
    login.submit()
    assert login.validity(login.EMAIL)["missing"]
    assert "login.php" in login.driver.current_url


def test_acceso_rechaza_email_mal_formado(login):
    login.fill("correo-invalido", "dato-ficticio")
    login.submit()
    assert login.validity(login.EMAIL)["mismatch"]
    assert "login.php" in login.driver.current_url
