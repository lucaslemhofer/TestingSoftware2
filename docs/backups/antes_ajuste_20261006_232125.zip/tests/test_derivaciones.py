import pytest




@pytest.mark.pendiente
@pytest.mark.skip(reason='Falta confirmar disponibilidad de RF04 y la accion de derivacion para el rol Juez/Vocal.')
def test_CP31_derivar_expediente_a_secretario_relator():
    """Derivar expediente a Secretario Relator: Verificar que un Juez/Vocal pueda asignar o derivar correctamente un expediente al Secretario Relator."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='Falta confirmar precondiciones y validaciones de RF04 para elegir un intento negativo que corresponda al flujo.')
def test_CP32_derivar_expediente_sin_condiciones_requeridas():
    """Derivar expediente sin condiciones requeridas: Intentar derivar un expediente cuando no se cumplen las condiciones necesarias para realizar la asignación."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')
