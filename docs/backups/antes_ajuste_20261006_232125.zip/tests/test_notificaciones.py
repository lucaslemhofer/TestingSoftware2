import pytest




@pytest.mark.pendiente
@pytest.mark.skip(reason='Aunque el formulario de alta contiene fecha_vencimiento, falta verificar el flujo de asignacion/modificacion del plazo.')
def test_CP12_establecer_vencimiento():
    """Establecer vencimiento: Verificar que pueda asignarse correctamente un plazo/vencimiento a un expediente."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='RF14 figura como Implementado, pero no se identifico el acceso de notificaciones en la navegacion inspeccionada.')
def test_CP25_consultar_notificaciones():
    """Consultar notificaciones: Verificar que un usuario habilitado pueda consultar las notificaciones asociadas a su actividad o expedientes."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')
