import pytest




@pytest.mark.pendiente
@pytest.mark.skip(reason='RF09 figura como Propuesto en el informe citado en la conversacion; no se confirma firmador activo.')
def test_CP13_firmar_sentencia():
    """Firmar sentencia: Verificar que un Juez/Vocal o Secretario Relator pueda realizar el proceso de firma de una sentencia habilitada para ello."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='RF09 figura como Propuesto; el estado que habilita la firma requiere preparacion de flujo y permisos.')
def test_CP14_intentar_firmar_documento_no_habilitado():
    """Intentar firmar documento no habilitado: Intentar firmar un documento que todavía no se encuentre en condiciones de ser firmado."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='Falta inspeccionar la pantalla de votos/adhesiones y confirmar disponibilidad de RF20.')
def test_CP15_registrar_voto_adhesi_n_en_sentencia():
    """Registrar voto/adhesión en sentencia: Verificar que se pueda registrar la participación correspondiente de un Juez/Vocal en el proceso de elaboración de una sentencia."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')
