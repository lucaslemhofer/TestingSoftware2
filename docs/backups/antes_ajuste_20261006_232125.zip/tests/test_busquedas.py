import pytest


def test_CP26_buscar_existente(expedientes, numero):
    expedientes.create(numero)
    expedientes.search(numero)
    assert len(expedientes.exact_rows(numero)) == 1





@pytest.mark.pendiente
@pytest.mark.skip(reason='RF16 figura como Implementado; se inspeccionaron filtros por numero, pero falta validar controles y combinacion de filtros.')
def test_CP27_buscar_causa_utilizando_filtros():
    """Buscar causa utilizando filtros: Realizar una búsqueda combinando criterios disponibles, como partes o tipo de causa, y verificar los resultados."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')


def test_CP28_buscar_causa_inexistente(expedientes, numero):
    expedientes.search(numero)
    assert not expedientes.exact_rows(numero)
    assert not expedientes.driver.find_elements('css selector', "a[href^='expediente_detalle.php?id=']")
