import pytest
from selenium.webdriver.common.by import By


def test_CP01_registrar_expediente(expedientes, numero):
    expedientes.create(numero)
    expedientes.driver.refresh()
    assert len(expedientes.exact_rows(numero)) == 1
    expedientes.detail(numero)


def test_CP02_obligatorios_vacios(expedientes):
    expedientes.new()
    expedientes.save()
    assert expedientes.driver.find_elements(By.CSS_SELECTOR, 'form input:invalid, form select:invalid')
    assert 'mesa_entrada.php' in expedientes.driver.current_url


def test_CP03_formato_incorrecto(expedientes, numero):
    invalid_number = '@@@###' + numero
    expedientes.new()
    expedientes.fill(invalid_number)
    expedientes.save()
    expedientes.search(invalid_number)
    assert len(expedientes.exact_rows(invalid_number)) == 0, 'SIGEX acepto caracteres @ y # en el numero'


def test_CP04_expediente_duplicado(expedientes, numero):
    expedientes.create(numero)
    expedientes.new()
    expedientes.fill(numero)
    expedientes.save()
    expedientes.search(numero)
    assert len(expedientes.exact_rows(numero)) == 1, 'SIGEX permitio duplicar el numero'


def test_CP05_limpiar_registro(expedientes, numero):
    expedientes.new()
    expedientes.fill(numero)
    expedientes.reset()
    assert expedientes.visible(expedientes.NUMBER).get_attribute('value') == ''
    expedientes.search(numero)
    assert not expedientes.exact_rows(numero)




def test_CP07_pase_interno(expedientes, numero):
    expedientes.create(numero)
    expedientes.detail(numero)
    expedientes.transfer('Pase automatizado ' + numero)


def test_CP11_consultar_expediente_en_tramite(expedientes, numero):
    expedientes.create(numero)
    expedientes.detail(numero)
    expedientes.transfer('Preparacion CP11 ' + numero)
    expedientes.detail(numero)
    assert 'En trámite' in expedientes.visible((By.TAG_NAME, 'body')).text



@pytest.mark.pendiente
@pytest.mark.skip(reason='No se identifico una accion de vuelta al tribunal de origen en los modulos inspeccionados; la funcion requiere confirmar flujo y rol.')
def test_CP06_tramitar_vuelta_al_origen():
    """Tramitar vuelta al origen: Verificar que un expediente pueda ser enviado nuevamente al tribunal de origen una vez finalizado el proceso correspondiente."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')



@pytest.mark.pendiente
@pytest.mark.skip(reason='La lista de estados del formulario no documenta que transicion es prohibida en cada estado; falta la matriz de transiciones.')
def test_CP08_realizar_una_transici_n_no_permitida():
    """Realizar una transición no permitida: Intentar efectuar un pase o cambio de estado que no corresponda al flujo establecido para el expediente."""
    raise NotImplementedError('Pendiente segun docs/MATRIZ.md')
