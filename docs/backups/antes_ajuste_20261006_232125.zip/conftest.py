import os
import re
import warnings
from datetime import datetime
from pathlib import Path

import pytest
import pytest_html
from dotenv import load_dotenv
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.chrome.service import Service

from pages.login_page import LoginPage
from pages.expedientes_page import ExpedientesPage
from selenium.webdriver.common.by import By

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env", override=False)


@pytest.fixture
def driver(request):
    options = Options()
    if os.getenv("HEADLESS", "true").lower() == "true":
        options.add_argument("--headless=new")
    options.add_argument("--window-size=1440,1000")
    options.add_argument("--disable-notifications")
    path = os.getenv("CHROMEDRIVER")
    browser = webdriver.Chrome(service=Service(path) if path else Service(), options=options)
    request.node._browser = browser
    browser.set_page_load_timeout(40)
    try:
        yield browser
    finally:
        browser.quit()
        request.node._browser = None


@pytest.fixture
def login(driver):
    return LoginPage(driver, int(os.getenv("TIMEOUT", "20"))).open(
        os.getenv("SIGEX_LOGIN_URL", "https://sigex.unaux.com/public/login.php")
    )


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    report = outcome.get_result()
    if not report.failed:
        return
    # Evita incluir secretos configurados en las excepciones del reporte.
    rendered = str(report.longrepr)
    for key in ("SIGEX_USER", "SIGEX_PASSWORD"):
        secret = os.getenv(key)
        if secret:
            rendered = rendered.replace(secret, "[REDACTADO]")
    report.longrepr = rendered
    browser = getattr(item, "_browser", None)
    if browser is None:
        return
    try:
        # Se ocultan campos y textos de cuentas de demostracion antes de capturar.
        browser.execute_script("""
            document.querySelectorAll('input,textarea').forEach(e=>e.style.visibility='hidden');
            const w=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
            const nodes=[]; while(w.nextNode()) nodes.push(w.currentNode);
            nodes.forEach(n=>{if(/@|password|contrase/i.test(n.textContent)) n.textContent='[REDACTADO]';});
        """)
        folder = ROOT / "screenshots"
        folder.mkdir(exist_ok=True)
        name = re.sub(r"[^a-zA-Z0-9_-]", "_", item.nodeid)
        path = folder / f"{name}_{report.when}_{datetime.now():%Y%m%d_%H%M%S_%f}.png"
        image = browser.get_screenshot_as_base64()
        import base64
        path.write_bytes(base64.b64decode(image))
        report.extras = getattr(report, "extras", []) + [pytest_html.extras.png(image, name="Captura de fallo")]
    except Exception as exc:
        warnings.warn(f"No se pudo generar la captura ({type(exc).__name__}).", RuntimeWarning)


@pytest.fixture
def expedientes(login):
    user, password = os.getenv('SIGEX_USER'), os.getenv('SIGEX_PASSWORD')
    if os.getenv('SIGEX_USE_DEMO', 'false').lower() == 'true':
        body = login.driver.find_element(By.TAG_NAME, 'body').text
        match_user = re.search(r'admin@[\w.-]+', body)
        match_password = re.search(r'Todas utilizan la contrase\S+\s+(\w+)', body, re.I)
        assert match_user and match_password, 'No se anuncian las cuentas de demostracion esperadas'
        user, password = match_user.group(), match_password.group(1)
    if not user or not password:
        pytest.skip('Configurar credenciales en .env o SIGEX_USE_DEMO=true para la demostracion publica')
    login.fill(user, password)
    login.submit()
    login.wait.until(lambda d: 'expedientes.php' in d.current_url)
    return ExpedientesPage(login.driver)


@pytest.fixture
def numero():
    from data.test_data import nuevo_expediente
    return nuevo_expediente()['numero']
