from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from pages.base_page import BasePage


class DocumentosPage(BasePage):
    def create_note(self, title, content):
        self.visible((By.CSS_SELECTOR, '#nuevo-borrador input[name="titulo"]')).send_keys(title)
        Select(self.visible((By.CSS_SELECTOR, '#nuevo-borrador select[name="tipo_documento"]'))).select_by_visible_text('Nota')
        self.visible((By.CSS_SELECTOR, '#nuevo-borrador textarea[name="contenido"]')).send_keys(content)
        self.click((By.CSS_SELECTOR, '#nuevo-borrador button[type="submit"]'))
        self.driver.refresh()
        assert title in self.visible((By.TAG_NAME, 'body')).text, 'El documento no aparece luego de recargar'
