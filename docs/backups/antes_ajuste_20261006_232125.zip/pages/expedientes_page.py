from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import Select
from pages.base_page import BasePage


class ExpedientesPage(BasePage):
    NUMBER = (By.ID, 'numero')

    def new(self):
        self.click((By.CSS_SELECTOR, "a[href='mesa_entrada.php']"))
        self.visible(self.NUMBER)

    def fill(self, number):
        self.click((By.XPATH, "//button[normalize-space()='Completar para prueba']"))
        field = self.visible(self.NUMBER)
        field.clear()
        field.send_keys(number)

    def save(self):
        self.click((By.CSS_SELECTOR, "form[action='../actions/expediente_guardar.php'] button[type='submit']"))

    def reset(self):
        self.click((By.CSS_SELECTOR, "button[type='reset']"))

    def search(self, number):
        self.click((By.CSS_SELECTOR, "a[href='expedientes.php']"))
        field = self.visible((By.NAME, 'numero'))
        field.clear()
        field.send_keys(number)
        self.click((By.XPATH, "//button[normalize-space()='Aplicar filtros']"))
        self.visible((By.NAME, 'numero'))

    def exact_rows(self, number):
        return self.driver.find_elements(By.XPATH, f"//tr[.//*[normalize-space()='{number}']]")

    def create(self, number):
        self.new()
        self.fill(number)
        self.save()
        self.search(number)
        assert len(self.exact_rows(number)) == 1, 'El alta no produjo exactamente un registro'

    def detail(self, number):
        self.search(number)
        rows = self.exact_rows(number)
        assert len(rows) == 1, 'Se esperaba un expediente unico'
        rows[0].find_element(By.CSS_SELECTOR, "a[href^='expediente_detalle.php?id=']").click()
        assert self.visible((By.TAG_NAME, 'h1')).text == number

    def transfer(self, comment):
        destination = Select(self.visible((By.NAME, 'usuario_destino_id')))
        options = [o for o in destination.options if 'Secretario Relator' in o.text]
        assert len(options) == 1
        destination.select_by_value(options[0].get_attribute('value'))
        Select(self.visible((By.NAME, 'estado_nuevo'))).select_by_visible_text('En trámite')
        self.visible((By.NAME, 'comentario')).send_keys(comment)
        self.click((By.CSS_SELECTOR, "form[action='../actions/pase_guardar.php'] button[type='submit']"))
        self.driver.refresh()
        text = self.visible((By.TAG_NAME, 'body')).text
        assert comment in text, 'El pase no quedo registrado en el historial'
        assert 'En trámite' in text
