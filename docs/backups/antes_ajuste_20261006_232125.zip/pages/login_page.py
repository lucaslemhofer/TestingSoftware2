from selenium.webdriver.common.by import By
from pages.base_page import BasePage


class LoginPage(BasePage):
    # Verificados en el DOM publico de SIGEX el 04/10/2026.
    EMAIL = (By.ID, "email")
    PASSWORD = (By.ID, "password")
    SUBMIT = (By.CSS_SELECTOR, "form[action='../actions/login_procesar.php'] button[type='submit']")

    def open(self, url):
        self.driver.get(url)
        self.visible(self.EMAIL)
        self.visible(self.PASSWORD)
        self.visible(self.SUBMIT)
        return self

    def fill(self, email, password):
        for locator, value in [(self.EMAIL, email), (self.PASSWORD, password)]:
            field = self.visible(locator)
            field.clear()
            field.send_keys(value)

    def submit(self):
        self.click(self.SUBMIT)

    def validity(self, locator):
        return self.driver.execute_script(
            "return {valid:arguments[0].validity.valid, missing:arguments[0].validity.valueMissing, mismatch:arguments[0].validity.typeMismatch}",
            self.visible(locator),
        )
